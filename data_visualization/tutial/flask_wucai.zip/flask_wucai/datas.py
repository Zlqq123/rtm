#!/usr/bin/env python
#coding=utf-8
import pandas as pd
df = pd.read_excel('./data/word.xlsx')

def get_data2(page):
    #print(df)
    item = df['item'].tolist()
    value = df['counts'].tolist()
    worldcloud = []
    worldcloud.append(item)
    worldcloud.append(value)
    print(worldcloud)
    data_dict = {'worldcloud': worldcloud}
    #print(data_dict)
    return data_dict.get(page, [])

def get_data(page):
    """
    获取生成数据
    :return:
    """

    data_dict = {
        "worldcloud": [[u'螺栓', u'发动机', u'座椅', u'方向盘', u'变速箱', u'悬挂',
                         u'弹簧', u'喷油嘴', u'车门', u'保险杠', u'安全气囊', u'导航系统',
                         u'轮胎', u'叶子板', u'天窗', u'空气净化器', u'车顶架', u'后视镜', u'车轮',
                         u'传动轴', u'刹车鼓', u'齿轮', u'转向节', u'ABS传感器', u'单向离合器',
                         u'保险丝', u'发电机', u'鼓风机', u'变速器轴', u'进排气管'],
                         [373, 371, 196, 182, 157, 156, 142, 140, 121, 120, 114, 96, 90, 86, 85, 77, 71, 70, 66, 65, 64, 62, 62, 59, 58,
                          58, 57, 57, 57, 57]],
        "contrast_data": [[0.9113212369026322, 0.9159988272087568, 0.9242252883962905, 0.9251669563626383, 0.8876632801161103,
                          0.8691756272401434], [0.9737546866630958, 0.9666666666666667, 0.9731659069407413, 0.9708312468703054,
                                                0.9778067885117493, 0.9693696883852692],
                         [0.9694636451133083, 0.9658140985651903, 0.9715846994535519,
                          0.9701402805611222, 0.9728781110402042, 0.9888132295719845]]
    }
    return data_dict.get(page, [])
