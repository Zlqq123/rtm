# API就是接口，访问URL时，会调用
import pandas as pd
import os
from flask import Blueprint, jsonify, request,render_template,redirect,json,Response
from App.models import *

ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
api = Blueprint("api", __name__, url_prefix='/')

@api.route('/')
def hello_world():
    """
    折线图/柱状图页面
    """
    return render_template('index.html')

@api.route('/get_date', methods=["POST"])
def overview_app():
    """
    折线图数据发送，index.html显示需要用的数据
    """
    if request.method == "POST":
        return jsonify(data=[[320, 332, 301, 334, 390, 330, 320], [120, 132, 101, 134, 90, 230, 210]])

# 从本地加载数据
#pressure_df = pd.read_excel(os.path.join(ROOT_PATH, '../data/brake_pressure_daily_sample_data.xlsx'))
#vacuum_df = pd.read_excel(os.path.join(ROOT_PATH, '../data/brake_vacuum_daily_sample_data.xlsx'))
# 读取本地材料组数据
mgc_df = pd.read_excel(os.path.join(ROOT_PATH, '../data/material_group.xlsx'))
print(mgc_df)

def get_spc_data(brake='Brake Left B'):
    """
        加液SPC分析
    """
    # pressure分析
    #print('brake=', brake)
    temp = pressure_df
    p_filterd = temp[temp['ProcessName']==brake]
    p_dates = [str(x) for x in p_filterd['Date'].unique()]
    p_means = [str(x) for x in p_filterd['mean'].values]
    # print('dates=\n', p_dates)
    # print('means=\n', p_means)
    # 设置upper和lower，以及target（平均线）
    p_upper = p_filterd['UCL_xbar'].values[0]
    p_lower = p_filterd['LCL_xbar'].values[0]
    p_target = p_filterd['CL_xbar'].values[0]
    
    # pressure std分析
    p_std_means = [str(x) for x in p_filterd['std'].values]
    p_std_upper = p_filterd['UCL_s'].values[0]
    p_std_lower = p_filterd['LCL_s'].values[0]
    p_std_target = p_filterd['CL_s'].values[0]

    # vacuum分析
    temp = vacuum_df[['Date', 'ProcessName', 'mean', 'UCL_xbar', 'LCL_xbar', 'CL_xbar']]
    v_filterd = temp[temp['ProcessName']==brake]
    v_dates = [str(x) for x in v_filterd['Date'].unique()]
    v_means = [str(x) for x in v_filterd['mean'].values]
    v_upper = v_filterd['UCL_xbar'].values[0]
    v_lower = v_filterd['LCL_xbar'].values[0]
    v_target = v_filterd['CL_xbar'].values[0]
    #print('v_upper=', v_upper)
    #print('v_lower=', v_lower)
    #print('v_target=', v_target)

    return p_filterd, p_dates, \
            p_upper, p_lower, p_target, p_means, \
            v_filterd, v_dates, \
            v_upper, v_lower, v_target, v_means, \
            p_std_upper, p_std_lower, p_std_target, p_std_means

@api.route('/spc_line')
def spc_line2():
    p_filterd, p_dates, p_upper, p_lower, p_target, p_means, \
                v_filterd, v_dates, v_upper, v_lower, v_target, v_means, \
                p_std_upper, p_std_lower, p_std_target, p_std_means = get_spc_data()
    # 使用html对数据进行渲染
    return render_template('spc_line.html', 
            p_df=p_filterd, p_dates=p_dates, \
            p_upper=p_upper, p_lower=p_lower, p_target=p_target, p_means=p_means, \
            v_df=v_filterd, v_dates=v_dates, \
            v_upper=v_upper, v_lower=v_lower, v_target=v_target, v_means=v_means, \
            p_std_upper=p_std_upper, p_std_lower=p_std_lower, p_std_target=p_std_target, p_std_means=p_std_means, \
                    )

@api.route('/spc_line/<brake>')
def spc_line(brake):
    #print('brake=', brake)
    p_filterd, p_dates, p_upper, p_lower, p_target, p_means, \
                v_filterd, v_dates, v_upper, v_lower, v_target, v_means, \
                p_std_upper, p_std_lower, p_std_target, p_std_means = get_spc_data(brake)
    # 使用html对数据进行渲染
    return render_template('spc_line.html', 
            p_df=p_filterd, p_dates=p_dates, \
            p_upper=p_upper, p_lower=p_lower, p_target=p_target, p_means=p_means, \
            v_df=v_filterd, v_dates=v_dates, \
            v_upper=v_upper, v_lower=v_lower, v_target=v_target, v_means=v_means, \
            p_std_upper=p_std_upper, p_std_lower=p_std_lower, p_std_target=p_std_target, p_std_means=p_std_means, \
                    )

@api.route('/index.html')
def index():
    #return index()
    return render_template('index.html')  

# SPC分析
@api.route('/spc_analysis')
def spc_analysis():
    #return index()
    return render_template('spc_analysis.html')  

# 解析数据，可以是GET或POST任意一种
def request_parse(req_data):
    '''解析请求数据并以json形式返回'''
    if req_data.method == 'POST':
        data = req_data.json
    elif req_data.method == 'GET':
        data = req_data.args
    return data

# 隐患字分类
@api.route("/danger_classification", methods=["GET", "POST"])
def danger_classification():
    result = None
    if request.method == "POST":
        if request.content_type.startswith('application/json'):
            #print('application/json')
            data = request.json.get('content')
        elif request.content_type.startswith('multipart/form-data'):
            #print('multipart/form-data')
            data = request.form.get('content')
        else:
            #print('else')
            data = request.values
        content = data['content']
        # 编写API进行预测
        #print('问题描述: {} 预测结果: {}'.format(content, result))
    return render_template('form.layouts.html', result=result)  

# 表格样式
@api.route('/form.layouts.html')
def form_layouts():
    return render_template('form.layouts.html')  


@api.route('/factory_overview')
def factory_overview():
    return render_template('factory_overview.html')

@api.route('/material_group')
def material_group():
    columns = mgc_df.columns
    return render_template('material_group.html', df=mgc_df, columns=columns)

@api.route('/datatables.html')
def datatables():
    return render_template('datatables.html')
