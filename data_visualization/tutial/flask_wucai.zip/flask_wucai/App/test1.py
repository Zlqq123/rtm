import pandas as pd

mgc_df = pd.read_excel('./data/mgc_class20201023.xlsx')
print(mgc_df)
print(type(mgc_df))
for index, temp in mgc_df.iterrows():
	#print(temp)
	print(temp['material_group_code'])
	print(temp['material_name'])
